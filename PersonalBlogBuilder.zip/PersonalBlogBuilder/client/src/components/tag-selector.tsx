import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Loader2, X, Plus, Check, Tag } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

interface TagSelectorProps {
  value: number[];
  onChange: (value: number[]) => void;
}

// Schema for creating a new tag
const createTagSchema = z.object({
  name: z.string().min(1, "Tag name is required"),
  slug: z.string().min(1, "Tag slug is required")
    .regex(/^[a-z0-9-]+$/, "Slug must contain only lowercase letters, numbers, and hyphens"),
});

type CreateTagValues = z.infer<typeof createTagSchema>;

export default function TagSelector({ value, onChange }: TagSelectorProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  
  // Fetch tags
  const {
    data: tags,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["/api/tags"],
  });
  
  // Create tag form
  const form = useForm<CreateTagValues>({
    resolver: zodResolver(createTagSchema),
    defaultValues: {
      name: "",
      slug: "",
    },
  });
  
  // Create tag mutation
  const createTagMutation = useMutation({
    mutationFn: async (data: CreateTagValues) => {
      const res = await apiRequest("POST", "/api/tags", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tags"] });
      toast({
        title: "Tag created",
        description: "The tag has been successfully created.",
      });
      
      // Add the new tag to selected tags
      onChange([...value, data.id]);
      
      // Close the dialog and reset form
      setCreateDialogOpen(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create tag: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Auto-generate slug from name
  useEffect(() => {
    const name = form.watch("name");
    if (name) {
      const slug = name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");
      form.setValue("slug", slug);
    }
  }, [form.watch("name")]);
  
  // Handle tag creation
  const onSubmit = (values: CreateTagValues) => {
    createTagMutation.mutate(values);
  };
  
  // Handle tag selection
  const toggleTag = (tagId: number) => {
    if (value.includes(tagId)) {
      onChange(value.filter(id => id !== tagId));
    } else {
      onChange([...value, tagId]);
    }
  };
  
  // Get selected tags data
  const selectedTags = tags?.filter(tag => value.includes(tag.id)) || [];
  
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2 min-h-[36px]">
        {selectedTags.map(tag => (
          <Badge key={tag.id} variant="secondary" className="flex items-center gap-1">
            {tag.name}
            <Button
              variant="ghost"
              size="sm"
              className="h-4 w-4 p-0 hover:bg-transparent"
              onClick={() => toggleTag(tag.id)}
            >
              <X className="h-3 w-3" />
              <span className="sr-only">Remove {tag.name}</span>
            </Button>
          </Badge>
        ))}
      </div>
      
      <div className="flex gap-2">
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              role="combobox"
              aria-expanded={open}
              className="justify-between w-full"
            >
              <span>Select tags</span>
              <Tag className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[300px] p-0">
            <Command>
              <CommandInput 
                placeholder="Search tags..." 
                value={search}
                onValueChange={setSearch}
              />
              {isLoading ? (
                <div className="flex justify-center items-center py-6">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : error ? (
                <CommandEmpty>Error loading tags</CommandEmpty>
              ) : (
                <>
                  <CommandEmpty>
                    {search ? (
                      <div className="py-6 text-center text-sm">
                        <p>No tags found for "{search}"</p>
                        {user && (
                          <Button 
                            variant="link" 
                            className="mt-2"
                            onClick={() => {
                              setOpen(false);
                              setCreateDialogOpen(true);
                              form.setValue("name", search);
                            }}
                          >
                            Create "{search}" tag
                          </Button>
                        )}
                      </div>
                    ) : (
                      "No tags found"
                    )}
                  </CommandEmpty>
                  <CommandGroup>
                    {tags?.map(tag => (
                      <CommandItem
                        key={tag.id}
                        value={tag.name}
                        onSelect={() => toggleTag(tag.id)}
                      >
                        <div className="flex items-center gap-2 w-full">
                          <Check
                            className={`h-4 w-4 ${
                              value.includes(tag.id) ? "opacity-100" : "opacity-0"
                            }`}
                          />
                          <span>{tag.name}</span>
                        </div>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </>
              )}
              
              {user && (
                <div className="border-t p-2">
                  <Button
                    variant="ghost"
                    className="w-full justify-start"
                    onClick={() => {
                      setOpen(false);
                      setCreateDialogOpen(true);
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Create new tag
                  </Button>
                </div>
              )}
            </Command>
          </PopoverContent>
        </Popover>
      </div>
      
      {/* Create Tag Dialog */}
      {user && (
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Tag</DialogTitle>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Technology" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="slug"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Slug</FormLabel>
                      <FormControl>
                        <Input placeholder="technology" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createTagMutation.isPending}
                  >
                    {createTagMutation.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    Create Tag
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
