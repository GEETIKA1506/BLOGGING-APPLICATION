import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Menu, X, Home, BookOpen, User, Settings, LogOut, PenTool, FileText } from "lucide-react";

export default function Navigation() {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const routes = [
    { name: "Home", path: "/", icon: <Home className="h-4 w-4 mr-2" /> },
    { name: "Blog", path: "/", icon: <BookOpen className="h-4 w-4 mr-2" /> },
  ];
  
  const userRoutes = user ? [
    { name: "Dashboard", path: "/dashboard", icon: <FileText className="h-4 w-4 mr-2" /> },
    { name: "New Post", path: "/post/new", icon: <PenTool className="h-4 w-4 mr-2" /> },
  ] : [];
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };
  
  return (
    <header className="bg-background border-b sticky top-0 z-10">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="font-bold text-xl flex items-center">
          <PenTool className="mr-2 h-5 w-5" />
          Wordsmith
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-4">
          {routes.map((route) => (
            <Link 
              key={route.path + route.name} 
              href={route.path}
              className={`px-3 py-2 text-sm font-medium rounded-md hover:bg-accent hover:text-accent-foreground transition-colors ${
                location === route.path ? "bg-accent text-accent-foreground" : ""
              }`}
            >
              {route.name}
            </Link>
          ))}
          
          {user && userRoutes.map((route) => (
            <Link 
              key={route.path + route.name} 
              href={route.path}
              className={`px-3 py-2 text-sm font-medium rounded-md hover:bg-accent hover:text-accent-foreground transition-colors ${
                location === route.path ? "bg-accent text-accent-foreground" : ""
              }`}
            >
              {route.name}
            </Link>
          ))}
        </nav>
        
        {/* User or Auth Button */}
        <div className="hidden md:block">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.avatarUrl || ""} alt={user.displayName || user.username} />
                    <AvatarFallback>{user.displayName?.charAt(0) || user.username.charAt(0)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/dashboard">
                    <User className="mr-2 h-4 w-4" />
                    <span>Dashboard</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/post/new">
                    <PenTool className="mr-2 h-4 w-4" />
                    <span>New Post</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link href="/auth">
              <Button>Sign In</Button>
            </Link>
          )}
        </div>
        
        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <SheetHeader className="pb-6">
                <SheetTitle className="flex items-center">
                  <PenTool className="mr-2 h-5 w-5" />
                  Wordsmith
                </SheetTitle>
              </SheetHeader>
              
              {/* Mobile Navigation Links */}
              <nav className="flex flex-col space-y-4">
                {routes.map((route) => (
                  <Link 
                    key={route.path + route.name}
                    href={route.path}
                    onClick={closeMobileMenu}
                    className={`px-3 py-2 text-sm font-medium rounded-md hover:bg-accent hover:text-accent-foreground transition-colors flex items-center ${
                      location === route.path ? "bg-accent text-accent-foreground" : ""
                    }`}
                  >
                    {route.icon}
                    {route.name}
                  </Link>
                ))}
                
                {user && userRoutes.map((route) => (
                  <Link 
                    key={route.path + route.name}
                    href={route.path}
                    onClick={closeMobileMenu}
                    className={`px-3 py-2 text-sm font-medium rounded-md hover:bg-accent hover:text-accent-foreground transition-colors flex items-center ${
                      location === route.path ? "bg-accent text-accent-foreground" : ""
                    }`}
                  >
                    {route.icon}
                    {route.name}
                  </Link>
                ))}
                
                {user ? (
                  <>
                    <div className="py-4">
                      <div className="flex items-center mb-2">
                        <Avatar className="h-8 w-8 mr-2">
                          <AvatarImage src={user.avatarUrl || ""} alt={user.displayName || user.username} />
                          <AvatarFallback>{user.displayName?.charAt(0) || user.username.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.displayName || user.username}</p>
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        className="w-full flex items-center justify-center"
                        onClick={() => {
                          handleLogout();
                          closeMobileMenu();
                        }}
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        Log out
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="py-4">
                    <Link href="/auth" onClick={closeMobileMenu}>
                      <Button className="w-full">Sign In</Button>
                    </Link>
                  </div>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
