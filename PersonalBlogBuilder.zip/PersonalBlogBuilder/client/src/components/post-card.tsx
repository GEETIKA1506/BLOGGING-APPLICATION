import { PostWithRelations } from "@shared/schema";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { CalendarIcon, MessageSquare, Eye } from "lucide-react";
import { format } from "date-fns";

interface PostCardProps {
  post: PostWithRelations;
}

export default function PostCard({ post }: PostCardProps) {
  // Format date for display
  const formattedDate = post.publishedAt
    ? format(new Date(post.publishedAt), "MMM d, yyyy")
    : "";
  
  // Truncate excerpt or content for preview
  const excerpt = post.excerpt || truncateContent(post.content);
  
  return (
    <Card className="overflow-hidden flex flex-col h-full transition-all hover:shadow-md">
      <Link href={`/post/${post.id}`} className="block">
        {post.featuredImageUrl && (
          <div className="relative h-48 w-full overflow-hidden">
            <img
              src={post.featuredImageUrl}
              alt={post.title}
              className="w-full h-full object-cover transition-transform hover:scale-105"
            />
          </div>
        )}
      </Link>
      
      <CardHeader className={post.featuredImageUrl ? "pt-4" : "pt-6"}>
        <div className="flex flex-wrap gap-2 mb-2">
          {post.categories.slice(0, 2).map(category => (
            <Link key={category.id} href={`/?category=${category.id}`}>
              <Badge variant="secondary" className="cursor-pointer">
                {category.name}
              </Badge>
            </Link>
          ))}
        </div>
        
        <Link href={`/post/${post.id}`} className="block">
          <h3 className="text-xl font-bold leading-tight hover:text-primary transition-colors line-clamp-2">
            {post.title}
          </h3>
        </Link>
      </CardHeader>
      
      <CardContent className="flex-grow">
        <p className="text-muted-foreground text-sm line-clamp-3">
          {excerpt}
        </p>
      </CardContent>
      
      <CardFooter className="flex justify-between items-center pt-2 pb-4 text-sm text-muted-foreground">
        <div className="flex items-center">
          <Avatar className="h-6 w-6 mr-2">
            <AvatarImage src={post.author.avatarUrl || ""} />
            <AvatarFallback>{post.author.displayName?.charAt(0) || post.author.username.charAt(0)}</AvatarFallback>
          </Avatar>
          <span>{post.author.displayName || post.author.username}</span>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex items-center">
            <CalendarIcon className="h-4 w-4 mr-1" />
            <span>{formattedDate}</span>
          </div>
          
          <div className="flex items-center">
            <Eye className="h-4 w-4 mr-1" />
            <span>{post.viewCount || 0}</span>
          </div>
          
          <div className="flex items-center">
            <MessageSquare className="h-4 w-4 mr-1" />
            <span>{post.commentCount || 0}</span>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}

// Helper function to truncate content from the rich text editor
function truncateContent(content: any): string {
  try {
    if (!content || !content.blocks) return "";
    
    // Extract text from the first few blocks
    const textBlocks = content.blocks
      .filter((block: any) => block.type !== 'atomic')
      .slice(0, 2)
      .map((block: any) => block.text);
    
    // Join and truncate
    const combinedText = textBlocks.join(' ');
    if (combinedText.length <= 150) return combinedText;
    return combinedText.substring(0, 147) + '...';
  } catch (error) {
    return "";
  }
}
