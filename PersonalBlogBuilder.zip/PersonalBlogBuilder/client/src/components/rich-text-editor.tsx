import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  Bold, 
  Italic, 
  List, 
  ListOrdered, 
  Link as LinkIcon, 
  Image as ImageIcon 
} from "lucide-react";

interface RichTextEditorProps {
  value: any;
  onChange?: (content: any) => void;
  readOnly?: boolean;
}

export default function RichTextEditor({ value, onChange, readOnly = false }: RichTextEditorProps) {
  // For a simpler implementation without Draft.js, we'll just store content as a string
  const [text, setText] = useState<string>(
    typeof value === 'string' ? value : (value?.text || '')
  );
  
  const [showImageDialog, setShowImageDialog] = useState(false);
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [imageUrl, setImageUrl] = useState("");
  const [imageAlt, setImageAlt] = useState("");
  const [linkUrl, setLinkUrl] = useState("");
  const [linkText, setLinkText] = useState("");
  const [textareaRef, setTextareaRef] = useState<HTMLTextAreaElement | null>(null);
  
  // Auto-save text to parent component when it changes
  useEffect(() => {
    if (onChange && !readOnly) {
      onChange({ text });
    }
  }, [text, onChange, readOnly]);
  
  // Handle text changes
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };
  
  // Focus the textarea and move cursor to the end
  const focusTextarea = () => {
    if (textareaRef) {
      textareaRef.focus();
      textareaRef.setSelectionRange(textareaRef.value.length, textareaRef.value.length);
    }
  };
  
  // Insert text at cursor position or replace selection
  const insertTextAtCursor = (textToInsert: string) => {
    if (!textareaRef) return;
    
    const start = textareaRef.selectionStart;
    const end = textareaRef.selectionEnd;
    const textBefore = text.substring(0, start);
    const textAfter = text.substring(end);
    
    setText(textBefore + textToInsert + textAfter);
    
    // Try to focus and set cursor position after the inserted text
    setTimeout(() => {
      textareaRef.focus();
      const newCursorPos = start + textToInsert.length;
      textareaRef.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };
  
  // Text formatting helpers
  const addBold = () => insertTextAtCursor('**Bold text**');
  const addItalic = () => insertTextAtCursor('*Italic text*');
  const addLink = () => setShowLinkDialog(true);
  const addImage = () => setShowImageDialog(true);
  const addUnorderedList = () => insertTextAtCursor('\n- List item\n- Another item\n');
  const addOrderedList = () => insertTextAtCursor('\n1. First item\n2. Second item\n');
  
  // Handle link and image submission
  const confirmLink = () => {
    insertTextAtCursor(`[${linkText || 'Link text'}](${linkUrl})`);
    setShowLinkDialog(false);
    setLinkUrl("");
    setLinkText("");
  };
  
  const confirmImage = () => {
    insertTextAtCursor(`![${imageAlt || 'Image description'}](${imageUrl})`);
    setShowImageDialog(false);
    setImageUrl("");
    setImageAlt("");
  };
  
  // For read-only mode, render with minimal formatting
  if (readOnly) {
    return (
      <div className="rich-text-content prose max-w-none whitespace-pre-wrap">
        {text}
      </div>
    );
  }
  
  return (
    <div>
      <Card className="p-1 mb-2">
        <div className="flex flex-wrap gap-1 border-b pb-1">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={addBold}
                >
                  <Bold className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Bold</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={addItalic}
                >
                  <Italic className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Italic</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={addUnorderedList}
                >
                  <List className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Bullet List</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={addOrderedList}
                >
                  <ListOrdered className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Numbered List</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={addLink}
                >
                  <LinkIcon className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Add Link</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={addImage}
                >
                  <ImageIcon className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Add Image</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </Card>
      
      <Textarea
        ref={el => setTextareaRef(el)}
        className="min-h-[200px] font-mono"
        placeholder="Write your content here..."
        value={text}
        onChange={handleTextChange}
        disabled={readOnly}
      />
      
      {/* Link Dialog */}
      <Dialog open={showLinkDialog} onOpenChange={setShowLinkDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Link</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="linkText">Link Text</Label>
              <Input
                id="linkText"
                placeholder="Text to display"
                value={linkText}
                onChange={(e) => setLinkText(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="url">URL</Label>
              <Input
                id="url"
                placeholder="https://example.com"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setShowLinkDialog(false)}>
              Cancel
            </Button>
            <Button type="button" onClick={confirmLink} disabled={!linkUrl}>
              Add Link
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Image Dialog */}
      <Dialog open={showImageDialog} onOpenChange={setShowImageDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Image</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="imageUrl">Image URL</Label>
              <Input
                id="imageUrl"
                placeholder="https://example.com/image.jpg"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="imageAlt">Alt Text</Label>
              <Input
                id="imageAlt"
                placeholder="Description of the image"
                value={imageAlt}
                onChange={(e) => setImageAlt(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setShowImageDialog(false)}>
              Cancel
            </Button>
            <Button type="button" onClick={confirmImage} disabled={!imageUrl}>
              Add Image
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
