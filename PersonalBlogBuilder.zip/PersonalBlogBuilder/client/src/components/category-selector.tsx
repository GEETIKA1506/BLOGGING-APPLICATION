import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Loader2, X, Check, FolderClosed } from "lucide-react";

interface CategorySelectorProps {
  value: number[];
  onChange: (value: number[]) => void;
}

export default function CategorySelector({ value, onChange }: CategorySelectorProps) {
  const [open, setOpen] = useState(false);
  
  // Fetch categories
  const {
    data: categories,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  // Handle category selection
  const toggleCategory = (categoryId: number) => {
    if (value.includes(categoryId)) {
      onChange(value.filter(id => id !== categoryId));
    } else {
      onChange([...value, categoryId]);
    }
  };
  
  // Get selected categories data
  const selectedCategories = categories?.filter(category => value.includes(category.id)) || [];
  
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2 min-h-[36px]">
        {selectedCategories.map(category => (
          <Badge key={category.id} variant="secondary" className="flex items-center gap-1">
            {category.name}
            <Button
              variant="ghost"
              size="sm"
              className="h-4 w-4 p-0 hover:bg-transparent"
              onClick={() => toggleCategory(category.id)}
            >
              <X className="h-3 w-3" />
              <span className="sr-only">Remove {category.name}</span>
            </Button>
          </Badge>
        ))}
      </div>
      
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="justify-between w-full"
          >
            <span>Select categories</span>
            <FolderClosed className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[300px] p-0">
          <Command>
            <CommandInput placeholder="Search categories..." />
            {isLoading ? (
              <div className="flex justify-center items-center py-6">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : error ? (
              <CommandEmpty>Error loading categories</CommandEmpty>
            ) : (
              <>
                <CommandEmpty>No categories found</CommandEmpty>
                <CommandGroup>
                  {categories?.map(category => (
                    <CommandItem
                      key={category.id}
                      value={category.name}
                      onSelect={() => toggleCategory(category.id)}
                    >
                      <div className="flex items-center gap-2 w-full">
                        <Check
                          className={`h-4 w-4 ${
                            value.includes(category.id) ? "opacity-100" : "opacity-0"
                          }`}
                        />
                        <span>{category.name}</span>
                      </div>
                    </CommandItem>
                  ))}
                </CommandGroup>
              </>
            )}
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
}
