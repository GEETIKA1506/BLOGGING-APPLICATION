import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Image, Upload, X, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface ImageUploaderProps {
  value: string;
  onChange: (value: string) => void;
}

export default function ImageUploader({ value, onChange }: ImageUploaderProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [urlDialogOpen, setUrlDialogOpen] = useState(false);
  const [imageUrl, setImageUrl] = useState("");
  
  // Handle file upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file.",
        variant: "destructive",
      });
      return;
    }
    
    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Image must be less than 5MB.",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    
    try {
      const formData = new FormData();
      formData.append('image', file);
      
      // For file uploads, we need to use fetch directly rather than apiRequest
      // since apiRequest is set up for JSON data, not FormData
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }
      
      const data = await response.json();
      onChange(data.url);
      setUploadDialogOpen(false);
      
      toast({
        title: "Image uploaded",
        description: "Your image has been successfully uploaded.",
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  // Handle URL submission
  const handleUrlSubmit = () => {
    onChange(imageUrl);
    setUrlDialogOpen(false);
    setImageUrl("");
    
    toast({
      title: "Image added",
      description: "Your image URL has been added.",
    });
  };
  
  // Remove the image
  const removeImage = () => {
    onChange("");
    
    toast({
      title: "Image removed",
      description: "Featured image has been removed.",
    });
  };
  
  return (
    <div>
      {value ? (
        <Card className="overflow-hidden">
          <CardContent className="p-0 relative">
            <img
              src={value}
              alt="Featured"
              className="w-full h-auto object-cover"
              style={{ maxHeight: "200px" }}
            />
            <Button
              variant="destructive"
              size="icon"
              className="absolute top-2 right-2"
              onClick={removeImage}
            >
              <X className="h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-2">
          <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
            <Dialog open={urlDialogOpen} onOpenChange={setUrlDialogOpen}>
              <div className="flex gap-2">
                <DialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    onClick={() => setUploadDialogOpen(true)}
                    className="flex-1"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Upload Image
                  </Button>
                </DialogTrigger>
                
                <DialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    onClick={() => setUrlDialogOpen(true)}
                    className="flex-1"
                  >
                    <Image className="mr-2 h-4 w-4" />
                    Use URL
                  </Button>
                </DialogTrigger>
              </div>
              
              {/* Upload Dialog */}
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Upload Image</DialogTitle>
                  <DialogDescription>
                    Upload an image to use as your featured image.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="grid w-full max-w-sm items-center gap-1.5">
                  <Label htmlFor="image-upload">Image</Label>
                  <Input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                  />
                  <p className="text-xs text-muted-foreground">
                    Max file size: 5MB. Supported formats: JPG, PNG, GIF.
                  </p>
                </div>
                
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setUploadDialogOpen(false)}
                    disabled={isUploading}
                  >
                    Cancel
                  </Button>
                  {isUploading && (
                    <Button disabled>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </Button>
                  )}
                </DialogFooter>
              </DialogContent>
              
              {/* URL Dialog */}
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Image URL</DialogTitle>
                  <DialogDescription>
                    Enter the URL of the image you want to use.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="grid w-full max-w-sm items-center gap-1.5">
                  <Label htmlFor="image-url">Image URL</Label>
                  <Input
                    id="image-url"
                    type="text"
                    placeholder="https://example.com/image.jpg"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                  />
                </div>
                
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setUrlDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="button"
                    onClick={handleUrlSubmit}
                    disabled={!imageUrl}
                  >
                    Add Image
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </Dialog>
        </div>
      )}
    </div>
  );
}
