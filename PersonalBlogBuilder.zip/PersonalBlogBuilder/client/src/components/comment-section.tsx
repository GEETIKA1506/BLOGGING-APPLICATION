import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { CommentWithUser } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, MessageSquare, Reply, Trash2, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const commentSchema = z.object({
  content: z.string().min(1, "Comment cannot be empty"),
});

type CommentFormValues = z.infer<typeof commentSchema>;

interface CommentSectionProps {
  postId: number;
}

export default function CommentSection({ postId }: CommentSectionProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [replyTo, setReplyTo] = useState<number | null>(null);
  const [editingComment, setEditingComment] = useState<number | null>(null);
  
  // Fetch comments for the post
  const {
    data: comments,
    isLoading,
    error,
  } = useQuery<CommentWithUser[]>({
    queryKey: [`/api/posts/${postId}/comments`],
  });
  
  // Create comment form
  const form = useForm<CommentFormValues>({
    resolver: zodResolver(commentSchema),
    defaultValues: {
      content: "",
    },
  });
  
  // Edit comment form
  const editForm = useForm<CommentFormValues>({
    resolver: zodResolver(commentSchema),
    defaultValues: {
      content: "",
    },
  });
  
  // Set edit form value when editing a comment
  useEffect(() => {
    if (editingComment && comments) {
      const flatComments = flattenComments(comments);
      const comment = flatComments.find(c => c.id === editingComment);
      if (comment) {
        editForm.reset({ content: comment.content });
      }
    }
  }, [editingComment, comments, editForm]);
  
  // Create comment mutation
  const createCommentMutation = useMutation({
    mutationFn: async (data: CommentFormValues) => {
      const res = await apiRequest("POST", `/api/posts/${postId}/comments`, {
        ...data,
        parentId: replyTo,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}/comments`] });
      form.reset();
      setReplyTo(null);
      toast({
        title: "Comment posted",
        description: "Your comment has been successfully posted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to post comment: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update comment mutation
  const updateCommentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: CommentFormValues }) => {
      const res = await apiRequest("PUT", `/api/comments/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}/comments`] });
      setEditingComment(null);
      toast({
        title: "Comment updated",
        description: "Your comment has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update comment: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete comment mutation
  const deleteCommentMutation = useMutation({
    mutationFn: async (commentId: number) => {
      await apiRequest("DELETE", `/api/comments/${commentId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}/comments`] });
      toast({
        title: "Comment deleted",
        description: "Your comment has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete comment: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle comment submission
  const onSubmit = (values: CommentFormValues) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "You must be logged in to post a comment.",
        variant: "destructive",
      });
      return;
    }
    
    createCommentMutation.mutate(values);
  };
  
  // Handle comment update
  const onUpdate = (values: CommentFormValues) => {
    if (!editingComment) return;
    
    updateCommentMutation.mutate({
      id: editingComment,
      data: values,
    });
  };
  
  // Flatten nested comments for finding by ID
  const flattenComments = (comments: CommentWithUser[]): CommentWithUser[] => {
    let flat: CommentWithUser[] = [];
    
    for (const comment of comments) {
      flat.push(comment);
      if (comment.replies && comment.replies.length > 0) {
        flat = flat.concat(flattenComments(comment.replies));
      }
    }
    
    return flat;
  };
  
  return (
    <section className="mt-12">
      <h2 className="text-2xl font-bold mb-6 flex items-center">
        <MessageSquare className="mr-2 h-5 w-5" />
        Comments {comments && `(${flattenComments(comments).length})`}
      </h2>
      
      {/* Comment Form */}
      {user && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-lg">
              {replyTo ? "Reply to comment" : "Leave a comment"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea
                          placeholder="Write your comment here..."
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end gap-2">
                  {replyTo && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setReplyTo(null)}
                    >
                      Cancel Reply
                    </Button>
                  )}
                  
                  <Button
                    type="submit"
                    disabled={createCommentMutation.isPending}
                  >
                    {createCommentMutation.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    {replyTo ? "Reply" : "Post Comment"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}
      
      {!user && (
        <Card className="mb-8">
          <CardContent className="p-6 text-center">
            <p className="mb-4">You need to be logged in to post a comment.</p>
            <Button asChild>
              <a href="/auth">Login or Register</a>
            </Button>
          </CardContent>
        </Card>
      )}
      
      {/* Comments List */}
      {isLoading ? (
        <div className="flex justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      ) : error ? (
        <div className="text-center text-destructive p-4">
          <p>Error loading comments. Please try again.</p>
        </div>
      ) : comments && comments.length > 0 ? (
        <div className="space-y-6">
          {comments.map(comment => (
            <CommentItem
              key={comment.id}
              comment={comment}
              currentUser={user}
              onReply={(id) => setReplyTo(id)}
              onEdit={(id) => setEditingComment(id)}
              onDelete={deleteCommentMutation.mutate}
              isEditing={editingComment === comment.id}
              editForm={editForm}
              onUpdate={onUpdate}
              updatePending={updateCommentMutation.isPending}
              level={0}
            />
          ))}
        </div>
      ) : (
        <div className="text-center text-muted-foreground p-8 border rounded-md">
          <MessageSquare className="h-12 w-12 mx-auto mb-2 opacity-20" />
          <p>No comments yet. Be the first to comment!</p>
        </div>
      )}
    </section>
  );
}

interface CommentItemProps {
  comment: CommentWithUser;
  currentUser: any;
  onReply: (id: number) => void;
  onEdit: (id: number) => void;
  onDelete: (id: number) => void;
  isEditing: boolean;
  editForm: any;
  onUpdate: (values: CommentFormValues) => void;
  updatePending: boolean;
  level: number;
}

function CommentItem({
  comment,
  currentUser,
  onReply,
  onEdit,
  onDelete,
  isEditing,
  editForm,
  onUpdate,
  updatePending,
  level
}: CommentItemProps) {
  const maxDepth = 3; // Maximum nesting level
  
  return (
    <div className={`pl-${level * 4}`}>
      <Card className={level > 0 ? 'border-l-4 border-l-primary border-opacity-20' : ''}>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div className="flex items-center">
              <Avatar className="h-8 w-8 mr-2">
                <AvatarImage src={comment.author.avatarUrl || ""} />
                <AvatarFallback>
                  {comment.author.displayName?.charAt(0) || comment.author.username.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium text-sm">
                  {comment.author.displayName || comment.author.username}
                </p>
                <p className="text-xs text-muted-foreground">
                  {format(new Date(comment.createdAt), "MMM d, yyyy 'at' h:mm a")}
                </p>
              </div>
            </div>
            
            {currentUser && (
              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onReply(comment.id)}
                >
                  <Reply className="h-4 w-4 mr-1" />
                  Reply
                </Button>
                
                {(currentUser.id === comment.authorId || currentUser.isAdmin) && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onEdit(comment.id)}
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDelete(comment.id)}
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </>
                )}
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="py-2">
          {isEditing ? (
            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(onUpdate)} className="space-y-4">
                <FormField
                  control={editForm.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => onEdit(0)}
                  >
                    Cancel
                  </Button>
                  
                  <Button
                    type="submit"
                    disabled={updatePending}
                  >
                    {updatePending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    Update
                  </Button>
                </div>
              </form>
            </Form>
          ) : (
            <p className="whitespace-pre-wrap">{comment.content}</p>
          )}
        </CardContent>
      </Card>
      
      {/* Render nested replies */}
      {comment.replies && comment.replies.length > 0 && level < maxDepth && (
        <div className="mt-4 space-y-4 ml-8">
          {comment.replies.map(reply => (
            <CommentItem
              key={reply.id}
              comment={reply}
              currentUser={currentUser}
              onReply={onReply}
              onEdit={onEdit}
              onDelete={onDelete}
              isEditing={isEditing}
              editForm={editForm}
              onUpdate={onUpdate}
              updatePending={updatePending}
              level={level + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}
