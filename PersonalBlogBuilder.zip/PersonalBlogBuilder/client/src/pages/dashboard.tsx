import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Post, PostStatus } from "@shared/schema";
import Navigation from "@/components/navigation";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, Edit, Trash2, Eye, AlertTriangle, FileEdit, PenTool } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>("posts");
  const [postToDelete, setPostToDelete] = useState<Post | null>(null);
  
  // Fetch user's posts
  const {
    data: userPosts,
    isLoading: postsLoading,
    error: postsError,
  } = useQuery<Post[]>({
    queryKey: ["/api/user/posts"],
  });
  
  // Delete post mutation
  const deletePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      await apiRequest("DELETE", `/api/posts/${postId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Post deleted",
        description: "Your post has been successfully deleted.",
      });
      setPostToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete post: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update post status mutation
  const updatePostStatusMutation = useMutation({
    mutationFn: async ({ postId, status }: { postId: number; status: PostStatus }) => {
      await apiRequest("PUT", `/api/posts/${postId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Status updated",
        description: "Post status has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update status: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Filter posts based on status
  const draftPosts = userPosts?.filter(post => post.status === 'draft') || [];
  const publishedPosts = userPosts?.filter(post => post.status === 'published') || [];
  const scheduledPosts = userPosts?.filter(post => post.status === 'scheduled') || [];
  
  const getStatusBadge = (status: PostStatus) => {
    switch (status) {
      case 'draft':
        return <Badge variant="outline">Draft</Badge>;
      case 'published':
        return <Badge variant="secondary" className="bg-green-100 text-green-800">Published</Badge>;
      case 'scheduled':
        return <Badge variant="secondary">Scheduled</Badge>;
    }
  };
  
  const formatDate = (dateString?: string | Date) => {
    if (!dateString) return 'N/A';
    return format(new Date(dateString), 'MMM d, yyyy');
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <Link href="/post/new">
            <Button className="flex items-center gap-2">
              <PenTool className="h-4 w-4" />
              Create New Post
            </Button>
          </Link>
        </div>
        
        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Draft Posts</CardTitle>
              <CardDescription>Posts waiting to be published</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{draftPosts.length}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Published Posts</CardTitle>
              <CardDescription>Live posts visible to readers</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{publishedPosts.length}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Total Views</CardTitle>
              <CardDescription>Total post views</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">
                {userPosts?.reduce((sum, post) => sum + (post.viewCount || 0), 0) || 0}
              </p>
            </CardContent>
          </Card>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="posts">All Posts</TabsTrigger>
            <TabsTrigger value="drafts">Drafts</TabsTrigger>
            <TabsTrigger value="published">Published</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
          </TabsList>
          
          <TabsContent value="posts">
            <PostsTable 
              posts={userPosts} 
              isLoading={postsLoading} 
              error={postsError}
              onDelete={setPostToDelete}
              getStatusBadge={getStatusBadge}
              formatDate={formatDate}
              updateStatus={(postId, status) => 
                updatePostStatusMutation.mutate({ postId, status })
              }
            />
          </TabsContent>
          
          <TabsContent value="drafts">
            <PostsTable 
              posts={draftPosts} 
              isLoading={postsLoading} 
              error={postsError}
              onDelete={setPostToDelete}
              getStatusBadge={getStatusBadge}
              formatDate={formatDate}
              updateStatus={(postId, status) => 
                updatePostStatusMutation.mutate({ postId, status })
              }
            />
          </TabsContent>
          
          <TabsContent value="published">
            <PostsTable 
              posts={publishedPosts} 
              isLoading={postsLoading} 
              error={postsError}
              onDelete={setPostToDelete}
              getStatusBadge={getStatusBadge}
              formatDate={formatDate}
              updateStatus={(postId, status) => 
                updatePostStatusMutation.mutate({ postId, status })
              }
            />
          </TabsContent>
          
          <TabsContent value="scheduled">
            <PostsTable 
              posts={scheduledPosts} 
              isLoading={postsLoading} 
              error={postsError}
              onDelete={setPostToDelete}
              getStatusBadge={getStatusBadge}
              formatDate={formatDate}
              updateStatus={(postId, status) => 
                updatePostStatusMutation.mutate({ postId, status })
              }
            />
          </TabsContent>
        </Tabs>
      </main>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={!!postToDelete} onOpenChange={(open) => !open && setPostToDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Confirm Deletion
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the post "{postToDelete?.title}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2 sm:justify-end">
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button 
              variant="destructive"
              onClick={() => postToDelete && deletePostMutation.mutate(postToDelete.id)}
              disabled={deletePostMutation.isPending}
            >
              {deletePostMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface PostsTableProps {
  posts?: Post[];
  isLoading: boolean;
  error: Error | null;
  onDelete: (post: Post) => void;
  getStatusBadge: (status: PostStatus) => React.ReactNode;
  formatDate: (date?: string | Date) => string;
  updateStatus: (postId: number, status: PostStatus) => void;
}

function PostsTable({ 
  posts, 
  isLoading, 
  error, 
  onDelete,
  getStatusBadge,
  formatDate,
  updateStatus
}: PostsTableProps) {
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="text-center text-destructive py-8">
        Error loading posts: {error.message}
      </div>
    );
  }
  
  if (!posts || posts.length === 0) {
    return (
      <div className="text-center text-muted-foreground py-16">
        <FileEdit className="h-12 w-12 mx-auto mb-4 opacity-20" />
        <p className="text-lg">No posts found</p>
        <Link href="/post/new">
          <Button variant="outline" className="mt-4">Create your first post</Button>
        </Link>
      </div>
    );
  }
  
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Title</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Date</TableHead>
            <TableHead className="text-right">Views</TableHead>
            <TableHead className="text-center">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {posts.map((post) => (
            <TableRow key={post.id}>
              <TableCell className="font-medium">{post.title}</TableCell>
              <TableCell>{getStatusBadge(post.status as PostStatus)}</TableCell>
              <TableCell>
                {post.status === 'published' 
                  ? formatDate(post.publishedAt || undefined) 
                  : post.status === 'scheduled' 
                    ? formatDate(post.scheduledAt || undefined)
                    : formatDate(post.updatedAt)}
              </TableCell>
              <TableCell className="text-right">{post.viewCount || 0}</TableCell>
              <TableCell>
                <div className="flex justify-center gap-2">
                  <Link href={`/post/${post.id}`}>
                    <Button variant="ghost" size="icon" title="View">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href={`/post/edit/${post.id}`}>
                    <Button variant="ghost" size="icon" title="Edit">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    title="Delete"
                    onClick={() => onDelete(post)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  
                  {post.status === 'draft' && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => updateStatus(post.id, 'published')}
                    >
                      Publish
                    </Button>
                  )}
                  
                  {post.status === 'published' && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => updateStatus(post.id, 'draft')}
                    >
                      Unpublish
                    </Button>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
