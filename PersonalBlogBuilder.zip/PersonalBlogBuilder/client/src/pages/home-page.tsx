import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { PostWithRelations, Category, Tag } from "@shared/schema";
import Navigation from "@/components/navigation";
import PostCard from "@/components/post-card";
import { Loader2 } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export default function HomePage() {
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [tagFilter, setTagFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Fetch posts
  const {
    data: posts,
    isLoading: postsLoading,
    error: postsError,
  } = useQuery<PostWithRelations[]>({
    queryKey: ["/api/posts"],
  });
  
  // Fetch categories
  const {
    data: categories,
    isLoading: categoriesLoading,
  } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Fetch tags
  const {
    data: tags,
    isLoading: tagsLoading,
  } = useQuery<Tag[]>({
    queryKey: ["/api/tags"],
  });
  
  // Filter posts based on category, tag, and search query
  const filteredPosts = posts?.filter(post => {
    let matchesCategory = true;
    let matchesTag = true;
    let matchesSearch = true;
    
    // Filter by category
    if (categoryFilter) {
      matchesCategory = post.categories.some(cat => cat.id.toString() === categoryFilter);
    }
    
    // Filter by tag
    if (tagFilter) {
      matchesTag = post.tags.some(tag => tag.id.toString() === tagFilter);
    }
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      matchesSearch = 
        post.title.toLowerCase().includes(query) || 
        (post.excerpt?.toLowerCase().includes(query) || false);
    }
    
    return matchesCategory && matchesTag && matchesSearch;
  }) || [];
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      {/* Hero Section */}
      <div className="bg-primary text-primary-foreground py-16 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Wordsmith Blog</h1>
          <p className="text-xl mb-8">
            Discover insightful articles, tutorials, and stories
          </p>
          
          {/* Search */}
          <div className="relative max-w-md mx-auto">
            <Input
              type="text"
              placeholder="Search posts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white/10 text-white placeholder:text-white/60 border-white/20"
            />
            <svg
              className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                clipRule="evenodd"
              />
            </svg>
          </div>
        </div>
      </div>
      
      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="mb-8 flex flex-col md:flex-row gap-4">
          <div className="w-full md:w-1/2">
            <Select
              value={categoryFilter || "all-categories"}
              onValueChange={(value) => setCategoryFilter(value === "all-categories" ? null : value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-categories">All Categories</SelectItem>
                {categories?.map((category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="w-full md:w-1/2">
            <Select
              value={tagFilter || "all-tags"}
              onValueChange={(value) => setTagFilter(value === "all-tags" ? null : value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Filter by tag" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-tags">All Tags</SelectItem>
                {tags?.map((tag) => (
                  <SelectItem key={tag.id} value={tag.id.toString()}>
                    {tag.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Applied Filters */}
        {(categoryFilter || tagFilter || searchQuery) && (
          <div className="mb-6 flex flex-wrap gap-2">
            {categoryFilter && categories && (
              <Badge variant="secondary" className="flex items-center gap-1">
                Category: {categories.find(c => c.id.toString() === categoryFilter)?.name}
                <button 
                  onClick={() => setCategoryFilter(null)}
                  className="ml-1"
                >
                  ✕
                </button>
              </Badge>
            )}
            
            {tagFilter && tags && (
              <Badge variant="secondary" className="flex items-center gap-1">
                Tag: {tags.find(t => t.id.toString() === tagFilter)?.name}
                <button 
                  onClick={() => setTagFilter(null)}
                  className="ml-1"
                >
                  ✕
                </button>
              </Badge>
            )}
            
            {searchQuery && (
              <Badge variant="secondary" className="flex items-center gap-1">
                Search: {searchQuery}
                <button 
                  onClick={() => setSearchQuery("")}
                  className="ml-1"
                >
                  ✕
                </button>
              </Badge>
            )}
            
            <button 
              onClick={() => {
                setCategoryFilter(null);
                setTagFilter(null);
                setSearchQuery("");
              }}
              className="text-sm text-muted-foreground hover:text-foreground"
            >
              Clear all filters
            </button>
          </div>
        )}
        
        {/* Posts Grid */}
        {postsLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
          </div>
        ) : postsError ? (
          <div className="text-center text-destructive">
            Error loading posts. Please try again.
          </div>
        ) : filteredPosts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        ) : (
          <div className="text-center text-muted-foreground h-64 flex items-center justify-center">
            <div>
              <p className="text-xl mb-2">No posts found</p>
              <p>Try adjusting your filters or search query</p>
            </div>
          </div>
        )}
      </main>
      
      {/* Footer */}
      <footer className="bg-muted py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Wordsmith Blog. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
