import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { updatePostSchema, insertPostSchema, PostStatus } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import RichTextEditor from "@/components/rich-text-editor";
import CategorySelector from "@/components/category-selector";
import TagSelector from "@/components/tag-selector";
import ImageUploader from "@/components/image-uploader";
import Navigation from "@/components/navigation";
import { Loader2, Save, FileCheck, Calendar, Eye } from "lucide-react";
import { format } from "date-fns";

// Form schema for post creation and editing
const postFormSchema = z.object({
  title: z.string().min(1, "Title is required"),
  content: z.any(), // Rich text content can be any type
  excerpt: z.string().optional(),
  status: z.enum(["draft", "published", "scheduled"]),
  featuredImageUrl: z.string().optional(),
  scheduledAt: z.string().optional(),
  categories: z.array(z.number()).default([]),
  tags: z.array(z.number()).default([]),
}).refine((data) => {
  // If status is scheduled, scheduledAt must be provided
  if (data.status === 'scheduled' && !data.scheduledAt) {
    return false;
  }
  return true;
}, {
  message: "Scheduled date is required when status is set to scheduled",
  path: ["scheduledAt"],
});

type PostFormValues = z.infer<typeof postFormSchema>;

export default function PostEditor() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("editor");
  const [autoSaveTimer, setAutoSaveTimer] = useState<NodeJS.Timeout | null>(null);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [previewContent, setPreviewContent] = useState<any>(null);
  
  // Determine if we're editing an existing post or creating a new one
  const isEditing = !!id && id !== 'new';
  
  // Fetch post data if editing
  const {
    data: post,
    isLoading: postLoading,
    error: postError,
  } = useQuery({
    queryKey: [`/api/posts/${id}`],
    enabled: isEditing,
  });
  
  // Create form with default values
  const form = useForm<PostFormValues>({
    resolver: zodResolver(postFormSchema),
    defaultValues: {
      title: "",
      content: {},
      excerpt: "",
      status: "draft",
      featuredImageUrl: "",
      scheduledAt: "",
      categories: [],
      tags: [],
    },
  });
  
  // Populate form with post data when available
  useEffect(() => {
    if (isEditing && post) {
      // Extract category and tag IDs
      const categoryIds = post?.categories?.map((cat: any) => cat.id) || [];
      const tagIds = post?.tags?.map((tag: any) => tag.id) || [];
      
      // Format scheduledAt date if exists
      let scheduledAt = post.scheduledAt ? 
        format(new Date(post.scheduledAt), "yyyy-MM-dd'T'HH:mm") : 
        '';
      
      form.reset({
        title: post.title || '',
        content: post.content || {},
        excerpt: post.excerpt || "",
        status: (post.status as PostStatus) || "draft",
        featuredImageUrl: post.featuredImageUrl || "",
        scheduledAt,
        categories: categoryIds,
        tags: tagIds,
      });
    }
  }, [isEditing, post, form]);
  
  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (data: PostFormValues) => {
      try {
        const res = await apiRequest("POST", "/api/posts", data);
        const jsonData = await res.json();
        
        // If the response has validation errors, throw an error with details
        if (!res.ok && jsonData.errors) {
          const errorMessages = [];
          
          // Extract error messages from Zod validation errors
          if (jsonData.errors._errors) {
            errorMessages.push(...jsonData.errors._errors);
          }
          
          // Check for specific field errors
          for (const field in jsonData.errors) {
            if (field !== '_errors' && jsonData.errors[field]._errors) {
              jsonData.errors[field]._errors.forEach((err: string) => {
                errorMessages.push(`${field}: ${err}`);
              });
            }
          }
          
          throw new Error(errorMessages.join(', ') || jsonData.message || 'Validation failed');
        }
        
        return jsonData;
      } catch (err) {
        if (err instanceof Error) {
          throw err;
        }
        throw new Error('An unexpected error occurred');
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/posts"] });
      
      toast({
        title: "Post created",
        description: "Your post has been successfully created.",
      });
      
      // Navigate to the post view or back to dashboard
      if (data.status === "published") {
        navigate(`/post/${data.id}`);
      } else {
        navigate("/dashboard");
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to create post",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update post mutation
  const updatePostMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: PostFormValues }) => {
      const res = await apiRequest("PUT", `/api/posts/${id}`, data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/posts"] });
      
      toast({
        title: "Post updated",
        description: "Your post has been successfully updated.",
      });
      
      setLastSaved(new Date());
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update post: " + error.message,
        variant: "destructive",
      });
    },
  });
  
  // Auto-save function
  const autoSave = () => {
    if (isEditing && form.formState.isDirty) {
      const values = form.getValues();
      updatePostMutation.mutate({ id, data: values });
    }
  };
  
  // Set up auto-save timer
  useEffect(() => {
    if (autoSaveTimer) {
      clearInterval(autoSaveTimer);
    }
    
    // Auto-save every 30 seconds
    const timer = setInterval(autoSave, 30000);
    setAutoSaveTimer(timer);
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isEditing, form.formState.isDirty]);
  
  // Handle form submission
  const onSubmit = (values: PostFormValues) => {
    if (isEditing) {
      updatePostMutation.mutate({ id, data: values });
    } else {
      createPostMutation.mutate(values);
    }
  };
  
  // Handle preview tab
  const handlePreview = () => {
    setPreviewContent(form.getValues().content);
    setActiveTab("preview");
  };
  
  // Loading state
  if (isEditing && postLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }
  
  // Error state
  if (isEditing && postError) {
    return (
      <div className="text-center text-destructive min-h-screen flex flex-col justify-center">
        <p className="text-2xl">Error loading post</p>
        <p>{(postError as Error).message}</p>
        <Button onClick={() => navigate("/dashboard")} className="mx-auto mt-4">
          Back to Dashboard
        </Button>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">
            {isEditing ? "Edit Post" : "Create New Post"}
          </h1>
          
          {/* Auto-save indicator */}
          {isEditing && lastSaved && (
            <div className="text-sm text-muted-foreground flex items-center">
              <FileCheck className="h-4 w-4 mr-1" />
              Last saved: {format(lastSaved, "h:mm a")}
            </div>
          )}
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="flex justify-between items-center mb-6">
            <TabsList>
              <TabsTrigger value="editor">Editor</TabsTrigger>
              <TabsTrigger value="preview" onClick={handlePreview}>Preview</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            
            <div className="flex gap-2">
              {isEditing && (
                <Button
                  variant="outline"
                  onClick={autoSave}
                  disabled={updatePostMutation.isPending || !form.formState.isDirty}
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
              )}
              
              <Button
                type="button"
                onClick={() => form.handleSubmit(onSubmit)()}
                disabled={createPostMutation.isPending || updatePostMutation.isPending}
              >
                {(createPostMutation.isPending || updatePostMutation.isPending) && (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                )}
                {isEditing ? "Update" : "Publish"}
              </Button>
            </div>
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <TabsContent value="editor">
                <Card>
                  <CardContent className="pt-6">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem className="mb-4">
                          <FormLabel>Title</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Enter post title"
                              className="text-xl font-medium"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="content"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Content</FormLabel>
                          <FormControl>
                            <RichTextEditor
                              value={field.value}
                              onChange={field.onChange}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="preview">
                <Card>
                  <CardContent className="pt-6">
                    <h1 className="text-3xl font-bold mb-4">{form.getValues().title}</h1>
                    
                    {form.getValues().featuredImageUrl && (
                      <div className="mb-6">
                        <img 
                          src={form.getValues().featuredImageUrl} 
                          alt={form.getValues().title}
                          className="w-full h-auto rounded-md"
                        />
                      </div>
                    )}
                    
                    <div className="prose max-w-none">
                      <RichTextEditor
                        value={previewContent}
                        readOnly
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="settings">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Post Settings</CardTitle>
                      <CardDescription>
                        Configure publication details
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="excerpt"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Excerpt</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Enter a brief summary of your post"
                                className="resize-none"
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              A short summary displayed in post listings.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Status</FormLabel>
                            <Select
                              value={field.value}
                              onValueChange={field.onChange}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select post status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="draft">Draft</SelectItem>
                                <SelectItem value="published">Published</SelectItem>
                                <SelectItem value="scheduled">Scheduled</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {form.watch("status") === "scheduled" && (
                        <FormField
                          control={form.control}
                          name="scheduledAt"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Schedule Date</FormLabel>
                              <FormControl>
                                <div className="flex items-center">
                                  <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                                  <Input
                                    type="datetime-local"
                                    {...field}
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Content Organization</CardTitle>
                      <CardDescription>
                        Organize your post with categories and tags
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="categories"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Categories</FormLabel>
                            <FormControl>
                              <CategorySelector
                                value={field.value || []}
                                onChange={field.onChange}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="tags"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tags</FormLabel>
                            <FormControl>
                              <TagSelector
                                value={field.value || []}
                                onChange={field.onChange}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="featuredImageUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Featured Image</FormLabel>
                            <FormControl>
                              <ImageUploader
                                value={field.value || ""}
                                onChange={field.onChange}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </form>
          </Form>
        </Tabs>
      </main>
    </div>
  );
}
