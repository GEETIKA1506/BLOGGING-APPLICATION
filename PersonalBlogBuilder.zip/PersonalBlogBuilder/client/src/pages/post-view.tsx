import { useEffect } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { PostWithRelations } from "@shared/schema";
import Navigation from "@/components/navigation";
import CommentSection from "@/components/comment-section";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, Clock, Eye, MessageSquare, Edit, ChevronLeft } from "lucide-react";
import { format } from "date-fns";
import RichTextEditor from "@/components/rich-text-editor";

export default function PostView() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  
  // Fetch post data
  const {
    data: post,
    isLoading,
    error,
  } = useQuery<PostWithRelations>({
    queryKey: [`/api/posts/${id}`],
  });
  
  // Check if the current user is the author
  const isAuthor = user && post && user.id === post.authorId;
  
  // Loading state
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }
  
  // Error state
  if (error || !post) {
    return (
      <div className="text-center text-destructive min-h-screen flex flex-col justify-center">
        <p className="text-2xl">Error loading post</p>
        <p>{error ? (error as Error).message : "Post not found"}</p>
        <Link href="/">
          <Button className="mx-auto mt-4">
            Back to Home
          </Button>
        </Link>
      </div>
    );
  }
  
  // Format date for display
  const formattedDate = post.publishedAt
    ? format(new Date(post.publishedAt), "MMMM d, yyyy")
    : "";
    
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="pl-0">
              <ChevronLeft className="h-4 w-4 mr-1" /> Back to Home
            </Button>
          </Link>
        </div>
        
        {/* Featured Image */}
        {post.featuredImageUrl && (
          <div className="mb-8">
            <img
              src={post.featuredImageUrl}
              alt={post.title}
              className="w-full h-auto object-cover rounded-lg"
              style={{ maxHeight: "500px" }}
            />
          </div>
        )}
        
        {/* Post Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
          
          <div className="flex flex-wrap items-center gap-4 mb-6">
            {/* Author info */}
            <div className="flex items-center">
              <Avatar className="h-10 w-10 mr-2">
                <AvatarImage src={post.author.avatarUrl || ""} />
                <AvatarFallback>{post.author.displayName?.charAt(0) || post.author.username.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{post.author.displayName || post.author.username}</p>
                <p className="text-sm text-muted-foreground">Author</p>
              </div>
            </div>
            
            {/* Date */}
            <div className="flex items-center text-muted-foreground">
              <Clock className="h-4 w-4 mr-1" />
              <span>{formattedDate}</span>
            </div>
            
            {/* View count */}
            <div className="flex items-center text-muted-foreground">
              <Eye className="h-4 w-4 mr-1" />
              <span>{post.viewCount || 0} views</span>
            </div>
            
            {/* Comment count */}
            <div className="flex items-center text-muted-foreground">
              <MessageSquare className="h-4 w-4 mr-1" />
              <span>{post.commentCount || 0} comments</span>
            </div>
            
            {/* Edit button for author */}
            {isAuthor && (
              <Link href={`/post/edit/${post.id}`}>
                <Button variant="outline" size="sm">
                  <Edit className="h-4 w-4 mr-1" /> Edit
                </Button>
              </Link>
            )}
          </div>
          
          {/* Categories and Tags */}
          <div className="flex flex-wrap gap-2 mb-6">
            {post.categories.map(category => (
              <Link key={category.id} href={`/?category=${category.id}`}>
                <Badge variant="secondary" className="cursor-pointer">
                  {category.name}
                </Badge>
              </Link>
            ))}
            
            {post.tags.map(tag => (
              <Link key={tag.id} href={`/?tag=${tag.id}`}>
                <Badge variant="outline" className="cursor-pointer">
                  #{tag.name}
                </Badge>
              </Link>
            ))}
          </div>
        </div>
        
        {/* Post Content */}
        <div className="prose max-w-none mb-12">
          <RichTextEditor value={post.content} readOnly />
        </div>
        
        {/* Comment Section */}
        <CommentSection postId={post.id} />
      </main>
      
      {/* Footer */}
      <footer className="bg-muted py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Wordsmith Blog. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
