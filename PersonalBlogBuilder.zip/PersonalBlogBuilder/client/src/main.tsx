import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Polyfill for 'global' used by Draft.js
if (typeof window !== 'undefined') {
  window.global = window;
}

createRoot(document.getElementById("root")!).render(<App />);
