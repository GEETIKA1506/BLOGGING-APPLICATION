import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import multer from "multer";
import path from "path";
import fs from "fs";
import { 
  insertPostSchema, 
  updatePostSchema,
  insertCategorySchema,
  insertTagSchema,
  insertCommentSchema
} from "@shared/schema";

// Setup file upload
const uploadDir = path.join(process.cwd(), "uploads");

// Create uploads directory if it doesn't exist
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
      const ext = path.extname(file.originalname);
      cb(null, uniqueSuffix + ext);
    }
  }),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    // Accept only images
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Check if user is authenticated middleware
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

// Check if user is admin middleware
const isAdmin = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated() && req.user.isAdmin) {
    return next();
  }
  res.status(403).json({ message: "Forbidden" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);
  
  // Serve uploaded files
  app.use('/uploads', express.static(uploadDir));
  
  // Post routes
  app.get("/api/posts", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const posts = await storage.getPublishedPosts(limit, offset);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Error fetching posts" });
    }
  });
  
  app.get("/api/posts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const post = await storage.getPost(id);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Increment view count if post is published
      if (post.status === 'published') {
        await storage.incrementPostView(post.id);
      }
      
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: "Error fetching post" });
    }
  });
  
  app.post("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const validationResult = insertPostSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.format() 
        });
      }
      
      const postData = {
        ...validationResult.data,
        authorId: req.user.id
      };
      
      const newPost = await storage.createPost(postData);
      
      // Handle categories
      if (req.body.categories && Array.isArray(req.body.categories)) {
        for (const categoryId of req.body.categories) {
          await storage.addCategoryToPost(newPost.id, parseInt(categoryId));
        }
      }
      
      // Handle tags
      if (req.body.tags && Array.isArray(req.body.tags)) {
        for (const tagId of req.body.tags) {
          await storage.addTagToPost(newPost.id, parseInt(tagId));
        }
      }
      
      // Get the enriched post with relations
      const enrichedPost = await storage.getPost(newPost.id);
      res.status(201).json(enrichedPost);
    } catch (error) {
      res.status(500).json({ message: "Error creating post" });
    }
  });
  
  app.put("/api/posts/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const post = await storage.getPost(id);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Check if user is the author or admin
      if (post.authorId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const validationResult = updatePostSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.format() 
        });
      }
      
      const updatedPost = await storage.updatePost(id, validationResult.data);
      
      // Update categories if provided
      if (req.body.categories && Array.isArray(req.body.categories)) {
        // Get current categories
        const currentCategories = await storage.getCategoriesByPost(id);
        const currentCategoryIds = currentCategories.map(c => c.id);
        
        // Categories to add
        const categoriesToAdd = req.body.categories
          .filter(cId => !currentCategoryIds.includes(parseInt(cId)))
          .map(cId => parseInt(cId));
          
        // Categories to remove
        const categoriesToRemove = currentCategoryIds
          .filter(cId => !req.body.categories.includes(cId.toString()));
          
        // Add new categories
        for (const categoryId of categoriesToAdd) {
          await storage.addCategoryToPost(id, categoryId);
        }
        
        // Remove categories
        for (const categoryId of categoriesToRemove) {
          await storage.removeCategoryFromPost(id, categoryId);
        }
      }
      
      // Update tags if provided
      if (req.body.tags && Array.isArray(req.body.tags)) {
        // Get current tags
        const currentTags = await storage.getTagsByPost(id);
        const currentTagIds = currentTags.map(t => t.id);
        
        // Tags to add
        const tagsToAdd = req.body.tags
          .filter(tId => !currentTagIds.includes(parseInt(tId)))
          .map(tId => parseInt(tId));
          
        // Tags to remove
        const tagsToRemove = currentTagIds
          .filter(tId => !req.body.tags.includes(tId.toString()));
          
        // Add new tags
        for (const tagId of tagsToAdd) {
          await storage.addTagToPost(id, tagId);
        }
        
        // Remove tags
        for (const tagId of tagsToRemove) {
          await storage.removeTagFromPost(id, tagId);
        }
      }
      
      // Get the enriched post with relations
      const enrichedPost = await storage.getPost(id);
      res.json(enrichedPost);
    } catch (error) {
      res.status(500).json({ message: "Error updating post" });
    }
  });
  
  app.delete("/api/posts/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const post = await storage.getPost(id);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Check if user is the author or admin
      if (post.authorId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      await storage.deletePost(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Error deleting post" });
    }
  });
  
  // User's posts
  app.get("/api/user/posts", isAuthenticated, async (req, res) => {
    try {
      const posts = await storage.getPostsByAuthor(req.user.id);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user posts" });
    }
  });
  
  // Category routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Error fetching categories" });
    }
  });
  
  app.get("/api/categories/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategory(id);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Error fetching category" });
    }
  });
  
  app.get("/api/categories/:id/posts", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const posts = await storage.getPostsByCategory(id);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Error fetching category posts" });
    }
  });
  
  app.post("/api/categories", isAdmin, async (req, res) => {
    try {
      const validationResult = insertCategorySchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.format() 
        });
      }
      
      const newCategory = await storage.createCategory(validationResult.data);
      res.status(201).json(newCategory);
    } catch (error) {
      res.status(500).json({ message: "Error creating category" });
    }
  });
  
  app.put("/api/categories/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategory(id);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      const validationResult = insertCategorySchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.format() 
        });
      }
      
      const updatedCategory = await storage.updateCategory(id, validationResult.data);
      res.json(updatedCategory);
    } catch (error) {
      res.status(500).json({ message: "Error updating category" });
    }
  });
  
  app.delete("/api/categories/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategory(id);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      await storage.deleteCategory(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Error deleting category" });
    }
  });
  
  // Tag routes
  app.get("/api/tags", async (req, res) => {
    try {
      const tags = await storage.getTags();
      res.json(tags);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tags" });
    }
  });
  
  app.get("/api/tags/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const tag = await storage.getTag(id);
      
      if (!tag) {
        return res.status(404).json({ message: "Tag not found" });
      }
      
      res.json(tag);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tag" });
    }
  });
  
  app.get("/api/tags/:id/posts", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const posts = await storage.getPostsByTag(id);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tag posts" });
    }
  });
  
  app.post("/api/tags", isAuthenticated, async (req, res) => {
    try {
      const validationResult = insertTagSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.format() 
        });
      }
      
      const newTag = await storage.createTag(validationResult.data);
      res.status(201).json(newTag);
    } catch (error) {
      res.status(500).json({ message: "Error creating tag" });
    }
  });
  
  app.put("/api/tags/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const tag = await storage.getTag(id);
      
      if (!tag) {
        return res.status(404).json({ message: "Tag not found" });
      }
      
      const validationResult = insertTagSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.format() 
        });
      }
      
      const updatedTag = await storage.updateTag(id, validationResult.data);
      res.json(updatedTag);
    } catch (error) {
      res.status(500).json({ message: "Error updating tag" });
    }
  });
  
  app.delete("/api/tags/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const tag = await storage.getTag(id);
      
      if (!tag) {
        return res.status(404).json({ message: "Tag not found" });
      }
      
      await storage.deleteTag(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Error deleting tag" });
    }
  });
  
  // Comment routes
  app.get("/api/posts/:postId/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.postId);
      const comments = await storage.getCommentsWithReplies(postId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Error fetching comments" });
    }
  });
  
  app.post("/api/posts/:postId/comments", isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.postId);
      const post = await storage.getPost(postId);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const validationResult = insertCommentSchema.safeParse({
        ...req.body,
        postId,
        authorId: req.user.id
      });
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationResult.error.format() 
        });
      }
      
      const newComment = await storage.createComment(validationResult.data);
      const enrichedComment = await storage.getComment(newComment.id);
      
      res.status(201).json(enrichedComment);
    } catch (error) {
      res.status(500).json({ message: "Error creating comment" });
    }
  });
  
  app.put("/api/comments/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const comment = await storage.getComment(id);
      
      if (!comment) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      // Check if user is the author or admin
      if (comment.authorId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedComment = await storage.updateComment(id, {
        content: req.body.content
      });
      
      const enrichedComment = await storage.getComment(id);
      res.json(enrichedComment);
    } catch (error) {
      res.status(500).json({ message: "Error updating comment" });
    }
  });
  
  app.delete("/api/comments/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const comment = await storage.getComment(id);
      
      if (!comment) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      // Check if user is the author or admin
      if (comment.authorId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      await storage.deleteComment(id);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Error deleting comment" });
    }
  });
  
  app.post("/api/comments/:id/approve", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const comment = await storage.getComment(id);
      
      if (!comment) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      const approvedComment = await storage.approveComment(id);
      const enrichedComment = await storage.getComment(id);
      
      res.json(enrichedComment);
    } catch (error) {
      res.status(500).json({ message: "Error approving comment" });
    }
  });
  
  // Image upload route
  app.post("/api/upload", isAuthenticated, upload.single('image'), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }
    
    const fileName = req.file.filename;
    const filePath = `/uploads/${fileName}`;
    
    res.json({ url: filePath });
  });

  const httpServer = createServer(app);

  return httpServer;
}
