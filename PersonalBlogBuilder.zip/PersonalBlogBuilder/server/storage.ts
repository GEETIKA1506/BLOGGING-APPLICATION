import { 
  users, 
  posts, 
  categories, 
  tags, 
  postCategories, 
  postTags, 
  comments, 
  type User, 
  type InsertUser, 
  type Post, 
  type InsertPost, 
  type UpdatePost, 
  type Category, 
  type InsertCategory, 
  type Tag, 
  type InsertTag, 
  type Comment, 
  type InsertComment,
  type PostWithRelations,
  type CommentWithUser,
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  
  // Post methods
  getPosts(limit?: number, offset?: number): Promise<PostWithRelations[]>;
  getPostsByAuthor(authorId: number): Promise<PostWithRelations[]>;
  getPostsByCategory(categoryId: number): Promise<PostWithRelations[]>;
  getPostsByTag(tagId: number): Promise<PostWithRelations[]>;
  getPost(id: number): Promise<PostWithRelations | undefined>;
  getPublishedPosts(limit?: number, offset?: number): Promise<PostWithRelations[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: number, data: UpdatePost): Promise<Post | undefined>;
  deletePost(id: number): Promise<boolean>;
  updatePostStatus(id: number, status: 'draft' | 'published' | 'scheduled'): Promise<Post | undefined>;
  incrementPostView(id: number): Promise<Post | undefined>;
  
  // Category methods
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, data: Partial<Category>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Tag methods
  getTags(): Promise<Tag[]>;
  getTag(id: number): Promise<Tag | undefined>;
  getTagBySlug(slug: string): Promise<Tag | undefined>;
  createTag(tag: InsertTag): Promise<Tag>;
  updateTag(id: number, data: Partial<Tag>): Promise<Tag | undefined>;
  deleteTag(id: number): Promise<boolean>;
  
  // Post-Category relation methods
  addCategoryToPost(postId: number, categoryId: number): Promise<boolean>;
  removeCategoryFromPost(postId: number, categoryId: number): Promise<boolean>;
  getCategoriesByPost(postId: number): Promise<Category[]>;
  
  // Post-Tag relation methods
  addTagToPost(postId: number, tagId: number): Promise<boolean>;
  removeTagFromPost(postId: number, tagId: number): Promise<boolean>;
  getTagsByPost(postId: number): Promise<Tag[]>;
  
  // Comment methods
  getComments(postId: number): Promise<CommentWithUser[]>;
  getComment(id: number): Promise<CommentWithUser | undefined>;
  createComment(comment: InsertComment): Promise<Comment>;
  updateComment(id: number, data: Partial<Comment>): Promise<Comment | undefined>;
  deleteComment(id: number): Promise<boolean>;
  approveComment(id: number): Promise<Comment | undefined>;
  getCommentsWithReplies(postId: number): Promise<CommentWithUser[]>;

  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private categories: Map<number, Category>;
  private tags: Map<number, Tag>;
  private postCategories: Map<number, { postId: number, categoryId: number }>;
  private postTags: Map<number, { postId: number, tagId: number }>;
  private comments: Map<number, Comment>;
  
  sessionStore: session.SessionStore;
  
  currentUserId: number;
  currentPostId: number;
  currentCategoryId: number;
  currentTagId: number;
  currentPostCategoryId: number;
  currentPostTagId: number;
  currentCommentId: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.categories = new Map();
    this.tags = new Map();
    this.postCategories = new Map();
    this.postTags = new Map();
    this.comments = new Map();
    
    this.currentUserId = 1;
    this.currentPostId = 1;
    this.currentCategoryId = 1;
    this.currentTagId = 1;
    this.currentPostCategoryId = 1;
    this.currentPostTagId = 1;
    this.currentCommentId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // Prune expired entries every 24h
    });
    
    // Add some default categories
    this.createCategory({ name: "General", slug: "general", description: "General posts" });
    this.createCategory({ name: "Technology", slug: "technology", description: "Tech related posts" });
    this.createCategory({ name: "Lifestyle", slug: "lifestyle", description: "Lifestyle posts" });
    
    // Add some default tags
    this.createTag({ name: "News", slug: "news" });
    this.createTag({ name: "Tutorial", slug: "tutorial" });
    this.createTag({ name: "Tips", slug: "tips" });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, isAdmin: false };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Post methods
  async getPosts(limit = 10, offset = 0): Promise<PostWithRelations[]> {
    const allPosts = Array.from(this.posts.values());
    const paginatedPosts = allPosts.slice(offset, offset + limit);
    
    return Promise.all(paginatedPosts.map(post => this.enrichPost(post)));
  }
  
  async getPostsByAuthor(authorId: number): Promise<PostWithRelations[]> {
    const authorPosts = Array.from(this.posts.values())
      .filter(post => post.authorId === authorId);
      
    return Promise.all(authorPosts.map(post => this.enrichPost(post)));
  }
  
  async getPostsByCategory(categoryId: number): Promise<PostWithRelations[]> {
    const postIds = Array.from(this.postCategories.values())
      .filter(rel => rel.categoryId === categoryId)
      .map(rel => rel.postId);
      
    const categoryPosts = Array.from(this.posts.values())
      .filter(post => postIds.includes(post.id));
      
    return Promise.all(categoryPosts.map(post => this.enrichPost(post)));
  }
  
  async getPostsByTag(tagId: number): Promise<PostWithRelations[]> {
    const postIds = Array.from(this.postTags.values())
      .filter(rel => rel.tagId === tagId)
      .map(rel => rel.postId);
      
    const tagPosts = Array.from(this.posts.values())
      .filter(post => postIds.includes(post.id));
      
    return Promise.all(tagPosts.map(post => this.enrichPost(post)));
  }
  
  async getPost(id: number): Promise<PostWithRelations | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;
    
    return this.enrichPost(post);
  }
  
  async getPublishedPosts(limit = 10, offset = 0): Promise<PostWithRelations[]> {
    const published = Array.from(this.posts.values())
      .filter(post => post.status === 'published' && 
        (post.publishedAt ? new Date(post.publishedAt) <= new Date() : true))
      .sort((a, b) => {
        const dateA = a.publishedAt ? new Date(a.publishedAt).getTime() : 0;
        const dateB = b.publishedAt ? new Date(b.publishedAt).getTime() : 0;
        return dateB - dateA; // Descending order
      });
      
    const paginatedPosts = published.slice(offset, offset + limit);
    return Promise.all(paginatedPosts.map(post => this.enrichPost(post)));
  }
  
  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.currentPostId++;
    const now = new Date();
    
    const post: Post = {
      ...insertPost,
      id,
      createdAt: now,
      updatedAt: now,
      viewCount: 0,
      publishedAt: insertPost.status === 'published' ? now : undefined,
    };
    
    this.posts.set(id, post);
    return post;
  }
  
  async updatePost(id: number, data: UpdatePost): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;
    
    const updatedPost: Post = {
      ...post,
      ...data,
      updatedAt: new Date(),
      // Update publishedAt if status is changed to published
      publishedAt: data.status === 'published' && post.status !== 'published' 
        ? new Date() 
        : post.publishedAt,
    };
    
    this.posts.set(id, updatedPost);
    return updatedPost;
  }
  
  async deletePost(id: number): Promise<boolean> {
    if (!this.posts.has(id)) return false;
    
    // Delete the post
    this.posts.delete(id);
    
    // Delete related data
    const pcToDelete = Array.from(this.postCategories.entries())
      .filter(([_, rel]) => rel.postId === id);
    pcToDelete.forEach(([key]) => this.postCategories.delete(key));
    
    const ptToDelete = Array.from(this.postTags.entries())
      .filter(([_, rel]) => rel.postId === id);
    ptToDelete.forEach(([key]) => this.postTags.delete(key));
    
    const commentsToDelete = Array.from(this.comments.entries())
      .filter(([_, comment]) => comment.postId === id);
    commentsToDelete.forEach(([key]) => this.comments.delete(key));
    
    return true;
  }
  
  async updatePostStatus(id: number, status: 'draft' | 'published' | 'scheduled'): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;
    
    const updatedPost: Post = {
      ...post,
      status,
      updatedAt: new Date(),
      publishedAt: status === 'published' && !post.publishedAt ? new Date() : post.publishedAt,
    };
    
    this.posts.set(id, updatedPost);
    return updatedPost;
  }
  
  async incrementPostView(id: number): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;
    
    const updatedPost: Post = {
      ...post,
      viewCount: (post.viewCount || 0) + 1,
    };
    
    this.posts.set(id, updatedPost);
    return updatedPost;
  }
  
  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values())
      .find(category => category.slug === slug);
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }
  
  async updateCategory(id: number, data: Partial<Category>): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category) return undefined;
    
    const updatedCategory: Category = { ...category, ...data };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    if (!this.categories.has(id)) return false;
    
    // Delete the category
    this.categories.delete(id);
    
    // Delete related data
    const pcToDelete = Array.from(this.postCategories.entries())
      .filter(([_, rel]) => rel.categoryId === id);
    pcToDelete.forEach(([key]) => this.postCategories.delete(key));
    
    return true;
  }
  
  // Tag methods
  async getTags(): Promise<Tag[]> {
    return Array.from(this.tags.values());
  }
  
  async getTag(id: number): Promise<Tag | undefined> {
    return this.tags.get(id);
  }
  
  async getTagBySlug(slug: string): Promise<Tag | undefined> {
    return Array.from(this.tags.values())
      .find(tag => tag.slug === slug);
  }
  
  async createTag(insertTag: InsertTag): Promise<Tag> {
    const id = this.currentTagId++;
    const tag: Tag = { ...insertTag, id };
    this.tags.set(id, tag);
    return tag;
  }
  
  async updateTag(id: number, data: Partial<Tag>): Promise<Tag | undefined> {
    const tag = this.tags.get(id);
    if (!tag) return undefined;
    
    const updatedTag: Tag = { ...tag, ...data };
    this.tags.set(id, updatedTag);
    return updatedTag;
  }
  
  async deleteTag(id: number): Promise<boolean> {
    if (!this.tags.has(id)) return false;
    
    // Delete the tag
    this.tags.delete(id);
    
    // Delete related data
    const ptToDelete = Array.from(this.postTags.entries())
      .filter(([_, rel]) => rel.tagId === id);
    ptToDelete.forEach(([key]) => this.postTags.delete(key));
    
    return true;
  }
  
  // Post-Category relation methods
  async addCategoryToPost(postId: number, categoryId: number): Promise<boolean> {
    if (!this.posts.has(postId) || !this.categories.has(categoryId)) return false;
    
    // Check if relation already exists
    const exists = Array.from(this.postCategories.values())
      .some(rel => rel.postId === postId && rel.categoryId === categoryId);
      
    if (exists) return true;
    
    const id = this.currentPostCategoryId++;
    this.postCategories.set(id, { postId, categoryId });
    return true;
  }
  
  async removeCategoryFromPost(postId: number, categoryId: number): Promise<boolean> {
    const entry = Array.from(this.postCategories.entries())
      .find(([_, rel]) => rel.postId === postId && rel.categoryId === categoryId);
      
    if (!entry) return false;
    
    this.postCategories.delete(entry[0]);
    return true;
  }
  
  async getCategoriesByPost(postId: number): Promise<Category[]> {
    const categoryIds = Array.from(this.postCategories.values())
      .filter(rel => rel.postId === postId)
      .map(rel => rel.categoryId);
      
    return categoryIds.map(id => this.categories.get(id)!).filter(Boolean);
  }
  
  // Post-Tag relation methods
  async addTagToPost(postId: number, tagId: number): Promise<boolean> {
    if (!this.posts.has(postId) || !this.tags.has(tagId)) return false;
    
    // Check if relation already exists
    const exists = Array.from(this.postTags.values())
      .some(rel => rel.postId === postId && rel.tagId === tagId);
      
    if (exists) return true;
    
    const id = this.currentPostTagId++;
    this.postTags.set(id, { postId, tagId });
    return true;
  }
  
  async removeTagFromPost(postId: number, tagId: number): Promise<boolean> {
    const entry = Array.from(this.postTags.entries())
      .find(([_, rel]) => rel.postId === postId && rel.tagId === tagId);
      
    if (!entry) return false;
    
    this.postTags.delete(entry[0]);
    return true;
  }
  
  async getTagsByPost(postId: number): Promise<Tag[]> {
    const tagIds = Array.from(this.postTags.values())
      .filter(rel => rel.postId === postId)
      .map(rel => rel.tagId);
      
    return tagIds.map(id => this.tags.get(id)!).filter(Boolean);
  }
  
  // Comment methods
  async getComments(postId: number): Promise<CommentWithUser[]> {
    const postComments = Array.from(this.comments.values())
      .filter(comment => comment.postId === postId);
      
    return Promise.all(postComments.map(async comment => {
      const author = await this.getUser(comment.authorId);
      return {
        ...comment,
        author: author!,
      };
    }));
  }
  
  async getComment(id: number): Promise<CommentWithUser | undefined> {
    const comment = this.comments.get(id);
    if (!comment) return undefined;
    
    const author = await this.getUser(comment.authorId);
    if (!author) return undefined;
    
    return {
      ...comment,
      author,
    };
  }
  
  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.currentCommentId++;
    const now = new Date();
    
    const comment: Comment = {
      ...insertComment,
      id,
      createdAt: now,
      updatedAt: now,
      isApproved: false,
    };
    
    this.comments.set(id, comment);
    return comment;
  }
  
  async updateComment(id: number, data: Partial<Comment>): Promise<Comment | undefined> {
    const comment = this.comments.get(id);
    if (!comment) return undefined;
    
    const updatedComment: Comment = {
      ...comment,
      ...data,
      updatedAt: new Date(),
    };
    
    this.comments.set(id, updatedComment);
    return updatedComment;
  }
  
  async deleteComment(id: number): Promise<boolean> {
    if (!this.comments.has(id)) return false;
    
    // Delete the comment
    this.comments.delete(id);
    
    // Delete child comments (replies)
    const repliesToDelete = Array.from(this.comments.entries())
      .filter(([_, comment]) => comment.parentId === id);
    repliesToDelete.forEach(([key]) => this.comments.delete(key));
    
    return true;
  }
  
  async approveComment(id: number): Promise<Comment | undefined> {
    const comment = this.comments.get(id);
    if (!comment) return undefined;
    
    const updatedComment: Comment = {
      ...comment,
      isApproved: true,
      updatedAt: new Date(),
    };
    
    this.comments.set(id, updatedComment);
    return updatedComment;
  }
  
  async getCommentsWithReplies(postId: number): Promise<CommentWithUser[]> {
    // Get all top-level comments
    const topLevelComments = Array.from(this.comments.values())
      .filter(comment => comment.postId === postId && !comment.parentId);
      
    // Organize into a tree structure
    const commentTree = await Promise.all(topLevelComments.map(async comment => {
      const commentWithUser = await this.getComment(comment.id);
      if (!commentWithUser) return null;
      
      // Get all replies for this comment
      const replies = await this.getRepliesForComment(comment.id);
      
      return {
        ...commentWithUser,
        replies,
      };
    }));
    
    return commentTree.filter(Boolean) as CommentWithUser[];
  }
  
  private async getRepliesForComment(parentId: number): Promise<CommentWithUser[]> {
    const replies = Array.from(this.comments.values())
      .filter(comment => comment.parentId === parentId);
      
    return Promise.all(replies.map(async reply => {
      const replyWithUser = await this.getComment(reply.id);
      if (!replyWithUser) return null;
      
      // Recursively get replies to this reply
      const nestedReplies = await this.getRepliesForComment(reply.id);
      
      return {
        ...replyWithUser,
        replies: nestedReplies,
      };
    })).then(results => results.filter(Boolean) as CommentWithUser[]);
  }
  
  // Helper method to enrich a post with related data
  private async enrichPost(post: Post): Promise<PostWithRelations> {
    const author = await this.getUser(post.authorId);
    const categories = await this.getCategoriesByPost(post.id);
    const tags = await this.getTagsByPost(post.id);
    const commentCount = Array.from(this.comments.values())
      .filter(comment => comment.postId === post.id).length;
    
    return {
      ...post,
      author: author!,
      categories,
      tags,
      commentCount,
    };
  }
}

export const storage = new MemStorage();
